from tkinter import *
from tkinter import messagebox
from test import Database

sqlDataBase = Database()
sqlDataBase._init_("SQLDataBase", "Mosque")
mosque_type = ["جامع", "مصلى", "مسجد"]



def insertIntoDatabase():
    global id_entry, name_entry, address_entry, type_choice, coordinates_entry, imam_name_entry, sqlDataBase
    for i in sqlDataBase.dispaly_all("Mosque"):
        if str(id_entry.get()) == str(i[0]):
            messagebox.showerror("Error", "ID is already used")
            return
        elif str(name_entry.get()).capitalize() == str(i[1]).capitalize():
            messagebox.showerror("Error", "Name is already used")
            return
    if not id_entry.get().isdigit():
        messagebox.showerror("Error", "ID must be numeric")
        return
    if '' not in (name_entry.get(), address_entry.get(), coordinates_entry.get(), imam_name_entry.get()):
        sqlDataBase.insert(id_entry.get(), name_entry.get(), address_entry.get(), type_choice.get(), coordinates_entry.get(), imam_name_entry.get())
        id_entry.delete(0, END)
        name_entry.delete(0,END)
        address_entry.delete(0, END)
        coordinates_entry.delete(0,END)
        imam_name_entry.delete(0, END)
        return
    else:
        messagebox.showerror("Error", "Some of the fields are NULL")

def DeleteFromDatabase():
    global id_entry, sqlDataBase
    for i in sqlDataBase.dispaly_all("Mosque"):
        if str(id_entry.get()) == str(i[0]):
            sqlDataBase.delete(id_entry.get())
            id_entry.delete(0, 'end')
            return
    messagebox.showerror("Error", "ID is not found (or not given)")

def DisplayAllValues():
    global list_box, sqlDataBase
    list_box.delete(0,END)
    for i in sqlDataBase.dispaly_all("Mosque"):
        list_box.insert("end",str(i[0]) + " " + i[1])

def SearchForValue():
    global sqlDataBase, id_entry, name_entry, type_choice, address_entry, coordinates_entry, imam_name_entry, list_box
    for i in sqlDataBase.dispaly_all("Mosque"):
        
        if str(i[1]) == str(name_entry.get()):
            id_entry.delete(0,END)
            id_entry.insert(0, i[0])
            address_entry.delete(0,END)
            address_entry.insert(0, i[2])
            type_choice.set(i[3])
            coordinates_entry.delete(0,END)
            coordinates_entry.insert(0,i[4])
            imam_name_entry.delete(0,END)
            imam_name_entry.insert(0,i[5])
            list_box.delete(0, END)
            list_box.insert(0, (i[0], i[1]))
            return
    messagebox.showerror("Error", "Mosque was not found")

def UpdateValues():
    global sqlDataBase, imam_name_entry, id_entry, name_entry
    for i in sqlDataBase.dispaly_all("Mosque"):
        if str(id_entry.get()) == str(i[0]) and name_entry.get() == i[1]:
            sqlDataBase.update(i[0], imam_name_entry.get())
            return
    messagebox.showerror("Error", "Mosque not found")

root = Tk()
type_choice = StringVar()
type_choice.set(mosque_type[1])
root.title("Mosque Managment System (MMS)")
# ------ PART 1 ------ #

id_label = Label(text="ID")
id_entry = Entry()
id_label.grid(row=0, column=0)
id_entry.grid(row=0, column=1)

name_label = Label(text="Name")
name_entry = Entry()
name_label.grid(row=0,column=2)
name_entry.grid(row=0, column=3)

type_label = Label(text="Type")
type_optionMenu = OptionMenu(root, type_choice, *mosque_type)
type_label.grid(row=1, column=0)
type_optionMenu.grid(row=1, column=1)

address_label = Label(text="Address")
address_entry = Entry()
address_label.grid(row=1, column=2)
address_entry.grid(row=1, column=3)

coordinates_label = Label(text="Coordinated")
coordinates_entry = Entry()
coordinates_label.grid(row=2, column=0)
coordinates_entry.grid(row=2, column=1)

imam_name_label = Label(text="Imam name")
imam_name_entry = Entry()
imam_name_label.grid(row=2, column=2)
imam_name_entry.grid(row=2, column=3)


# ------ PART 2 ------ #

list_box = Listbox(width=30, selectmode=SINGLE)
list_box.grid(row=0, column=4, rowspan=5)

# ------ PART 3 ------ #
display_all_button = Button(text="Display All", width=15, command=DisplayAllValues)
display_all_button.grid(row=3, column=1)

search_by_name_button = Button(text="Search By Name", width=15, command=SearchForValue)
search_by_name_button.grid(row=3, column=2)

update_button = Button(text="Update", width=15, command=UpdateValues)
update_button.grid(row=3, column=3)

add_entry_button = Button(text="Add Entry", width=15, command=insertIntoDatabase)
add_entry_button.grid(row=4, column=1)

delete_entry_button = Button(text="Delete Entry", width=15, command=DeleteFromDatabase)
delete_entry_button.grid(row=4, column=2)



# ------ PART 4 ------ #

display_map_button = Button(text="Display map", width=15)
display_map_button.grid(row=4, column=3)

# for i in sqlDataBase.dispaly_all("Mosque"):
#     print(i)

root.mainloop()

